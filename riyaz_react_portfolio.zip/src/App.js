
import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src="/cort pic.jpg" className="App-logo" alt="profile" />
        <h1>Shaik Riyaz</h1>
        <p>Computer Science Student | Data Science Enthusiast</p>
        <p>Email: riyazshaikplvd@gmail.com | Phone: +91 6281446962</p>
        <div className="links">
          <a href="#about">About</a>
          <a href="#skills">Skills</a>
          <a href="#projects">Projects</a>
          <a href="#contact">Contact</a>
        </div>
      </header>
      <section id="about">
        <h2>About Me</h2>
        <p>Highly motivated CSE student specializing in Data Science...</p>
      </section>
      <section id="skills">
        <h2>Skills</h2>
        <ul>
          <li>Python, Java</li>
          <li>React.js, Node.js</li>
          <li>MongoDB, Oracle SQL</li>
        </ul>
      </section>
      <section id="projects">
        <h2>Projects</h2>
        <p>Deep Fake Source Identifier using React.js, Django...</p>
      </section>
      <section id="contact">
        <h2>Contact</h2>
        <p>Email: riyazshaikplvd@gmail.com</p>
      </section>
    </div>
  );
}

export default App;
